/*Programa creado por Alejandro Barrachina Argudo
Actividad adicional fundamentos de programaci�n
Ejercicio 05 Tema 07*/
#pragma once
//Bibliotecas


#include "Header.h"
#include "Lista.h"

//Zona de inclusiones
bool carga(fstream &archivo, tLista &l);//carga la lista
void guardar(tLista &l); //guardar

