/*Programa creado por Alejandro Barrachina Argudo
Actividad adicional fundamentos de programaci�n
Ejercicio 05 Tema 07*/
#pragma once
//Bibliotecas
#include <iostream>
#include <locale>
#include <Windows.h>
#include <string>
#include <fstream>
using namespace std;


//Zona de prototipos
void color(int c);//Cambia el color de la consola de comandos
void ayuda();//Funci�n de ayuda al usuario