/*Programa creado por Alejandro Barrachina Argudo
Actividad adicional fundamentos de programaci�n
Ejercicio 05 Tema 07*/

#pragma once
//Bibliotecas
#include "Header.h"
#include "Lista.h"



//Zona de inclusiones
void ordenAlfa(tLista &l, int op); //orden de lista por orden alfab�tico
void ordenNum(tLista &l, int op); //orden de lista por orden num�rico
